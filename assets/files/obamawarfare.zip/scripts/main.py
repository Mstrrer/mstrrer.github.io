#obama warfare created by Mstrrer
import tkinter as tk
from tkinter import messagebox
import tkinter.font as tkFont
from winsound import PlaySound, SND_FILENAME
import random

w, h = 700, 700
background = "#303645"
title = "obama warfare"

icon = "assets/icon.png"
pointerimg = "assets/pointer.png"
enemyimg = "assets/enemy.png"

playhit = lambda: PlaySound("assets/hit.wav", SND_FILENAME)

window = tk.Tk()

def fire():
    playhit()
    ppos = canvas.coords(pointer)
    x, y = ppos[0], ppos[1]

    i = 0
    dead = None
    for target in targets:
        tpos = canvas.coords(target)
        tx, ty = tpos[0], tpos[1]
        if abs(tx - x) < 20 and abs(ty - y) < 20:
            dead = i
            break
        i += 1
    if dead != None:
        canvas.delete(targets[dead])
        del targets[dead]
    if len(targets) == 0:
        messagebox.showinfo("congragketatuibs", "you are true obama!..,")

def movekey(event):
    if event.char == "a":
        canvas.move(pointer, -20, 0)
    elif event.char == "d":
        canvas.move(pointer, 20, 0)
    elif event.char == "w":
        canvas.move(pointer, 0, -20)
    elif event.char == "s":
        canvas.move(pointer, 0, 20) 

window.title(title)
window.iconphoto(False, tk.PhotoImage(file=icon))

canvas = tk.Canvas(window, height=h+140, width=w, bg=background, highlightthickness=0)
canvas.pack()

controls = tk.Frame(window, bg="gray", highlightthickness = 3, highlightbackground="gray42")
controls.place(relwidth = 1, relheight = 0.25, relx = 0, rely = 0.75)
board = tk.Frame(controls, bg="green", highlightthickness = 3, highlightbackground="dark green")
board.place(relwidth = 0.35, relheight = 0.8, relx = 0.325, rely = 0.1)
fireButton = tk.Button(controls, text = "Fire", padx = 10, height = 20, pady = 50, fg = "white", bg = "#FF3636", command = fire)
fireButton.pack(side = tk.RIGHT, padx = 85, pady = 87)

pointer = canvas.create_text(w/2, h/2, text = "[    ]", fill = "#417843", font= tkFont.Font(size=14))

window.bind("<Key>", movekey)

random.seed()
targets = []
for i in range(10):
    x = random.randrange(20, w - 60)
    y = random.randrange(20, h - 80)
    valid = True
    for other in targets:
        pos = canvas.coords(other)
        px, py = pos[0], pos[1]
        if abs(px - x) < 20 and abs(py - y) < 20:
            valid = False
            break
    if (not valid):
        continue
    targets.append(canvas.create_oval(x, y, x + 15, y + 15, outline="gray", fill="white", width=2))


window.mainloop()